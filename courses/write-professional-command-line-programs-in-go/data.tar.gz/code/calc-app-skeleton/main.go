package main

import "calc-app/cmd"

func main() {
	cmd.Execute()
}
